// Copyright (c) 2000-2005 Progeny Systems Corporation.
//
// Consult license.html in the documentation directory for licensing
// information.

if (typeof(formfacesLoaded) != "undefined") {
  formfacesLoaded();
}